'use strict';

/**
 * @ngdoc function
 * @name inexdeoAdminApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the inexdeoAdminApp
 */
angular.module('inexdeoAdminApp')
.controller('MainCtrl', function () {
    
});